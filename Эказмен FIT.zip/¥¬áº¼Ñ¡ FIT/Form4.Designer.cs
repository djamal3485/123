﻿namespace Эказмен_FIT
{
    partial class Form4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form4));
            System.Windows.Forms.Label квитанцииLabel;
            this.button1 = new System.Windows.Forms.Button();
            this.___F_I_T__ХужаевDataSet = new Эказмен_FIT.@__F_I_T__ХужаевDataSet();
            this.администраторBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.администраторTableAdapter = new Эказмен_FIT.@__F_I_T__ХужаевDataSetTableAdapters.АдминистраторTableAdapter();
            this.tableAdapterManager = new Эказмен_FIT.@__F_I_T__ХужаевDataSetTableAdapters.TableAdapterManager();
            this.администраторBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.администраторBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.квитанцииTextBox = new System.Windows.Forms.TextBox();
            квитанцииLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.___F_I_T__ХужаевDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.администраторBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.администраторBindingNavigator)).BeginInit();
            this.администраторBindingNavigator.SuspendLayout();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(687, 390);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(101, 48);
            this.button1.TabIndex = 3;
            this.button1.Text = "Назад";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // ___F_I_T__ХужаевDataSet
            // 
            this.___F_I_T__ХужаевDataSet.DataSetName = "__F_I_T__ХужаевDataSet";
            this.___F_I_T__ХужаевDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // администраторBindingSource
            // 
            this.администраторBindingSource.DataMember = "Администратор";
            this.администраторBindingSource.DataSource = this.___F_I_T__ХужаевDataSet;
            // 
            // администраторTableAdapter
            // 
            this.администраторTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.UpdateOrder = Эказмен_FIT.@__F_I_T__ХужаевDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager.АдминистраторTableAdapter = this.администраторTableAdapter;
            this.tableAdapterManager.КлиентыTableAdapter = null;
            this.tableAdapterManager.Специалист_косметологииTableAdapter = null;
            this.tableAdapterManager.УслугиTableAdapter = null;
            // 
            // администраторBindingNavigator
            // 
            this.администраторBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.администраторBindingNavigator.BindingSource = this.администраторBindingSource;
            this.администраторBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.администраторBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.администраторBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.администраторBindingNavigatorSaveItem});
            this.администраторBindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.администраторBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.администраторBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.администраторBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.администраторBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.администраторBindingNavigator.Name = "администраторBindingNavigator";
            this.администраторBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.администраторBindingNavigator.Size = new System.Drawing.Size(808, 25);
            this.администраторBindingNavigator.TabIndex = 4;
            this.администраторBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Переместить в начало";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Переместить назад";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Положение";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Текущее положение";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(43, 15);
            this.bindingNavigatorCountItem.Text = "для {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Общее число элементов";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 6);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 20);
            this.bindingNavigatorMoveNextItem.Text = "Переместить вперед";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 20);
            this.bindingNavigatorMoveLastItem.Text = "Переместить в конец";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 6);
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorAddNewItem.Text = "Добавить";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 20);
            this.bindingNavigatorDeleteItem.Text = "Удалить";
            // 
            // администраторBindingNavigatorSaveItem
            // 
            this.администраторBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.администраторBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("администраторBindingNavigatorSaveItem.Image")));
            this.администраторBindingNavigatorSaveItem.Name = "администраторBindingNavigatorSaveItem";
            this.администраторBindingNavigatorSaveItem.Size = new System.Drawing.Size(23, 23);
            this.администраторBindingNavigatorSaveItem.Text = "Сохранить данные";
            this.администраторBindingNavigatorSaveItem.Click += new System.EventHandler(this.администраторBindingNavigatorSaveItem_Click);
            // 
            // квитанцииLabel
            // 
            квитанцииLabel.AutoSize = true;
            квитанцииLabel.Location = new System.Drawing.Point(245, 136);
            квитанцииLabel.Name = "квитанцииLabel";
            квитанцииLabel.Size = new System.Drawing.Size(64, 13);
            квитанцииLabel.TabIndex = 4;
            квитанцииLabel.Text = "Квитанции:";
            // 
            // квитанцииTextBox
            // 
            this.квитанцииTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.администраторBindingSource, "Квитанции", true));
            this.квитанцииTextBox.Location = new System.Drawing.Point(315, 133);
            this.квитанцииTextBox.Name = "квитанцииTextBox";
            this.квитанцииTextBox.Size = new System.Drawing.Size(171, 20);
            this.квитанцииTextBox.TabIndex = 5;
            // 
            // Form4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.ClientSize = new System.Drawing.Size(808, 458);
            this.Controls.Add(квитанцииLabel);
            this.Controls.Add(this.квитанцииTextBox);
            this.Controls.Add(this.администраторBindingNavigator);
            this.Controls.Add(this.button1);
            this.Name = "Form4";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "F.I.T";
            this.Load += new System.EventHandler(this.Form4_Load);
            ((System.ComponentModel.ISupportInitialize)(this.___F_I_T__ХужаевDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.администраторBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.администраторBindingNavigator)).EndInit();
            this.администраторBindingNavigator.ResumeLayout(false);
            this.администраторBindingNavigator.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private __F_I_T__ХужаевDataSet ___F_I_T__ХужаевDataSet;
        private System.Windows.Forms.BindingSource администраторBindingSource;
        private __F_I_T__ХужаевDataSetTableAdapters.АдминистраторTableAdapter администраторTableAdapter;
        private __F_I_T__ХужаевDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator администраторBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton администраторBindingNavigatorSaveItem;
        private System.Windows.Forms.TextBox квитанцииTextBox;
    }
}